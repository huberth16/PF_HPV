<h1 align="center"> Biblioteca para pasar a escala de grises imagenes y enviarlas por correo </h1>
<h1>Proyecto final del curso Python nivel 2 de la academia tecnológica de la UCR</h1>

## Estudiante Huberth Perez. 
 En el presente repositorio de código encontrarás mis proyecto final.

El archivo de configuración para las funciones y sus pruebas se llama setup.py